# Spotify Clone with HTML & CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/omerko96/pen/wvXgQZK](https://codepen.io/omerko96/pen/wvXgQZK).

Video - https://youtu.be/xVZqEmRQjLM